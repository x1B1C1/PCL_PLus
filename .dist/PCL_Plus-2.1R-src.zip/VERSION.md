# V1.0-SRC · 源码快照（内容已更新到 1.1.1R）

本目录是 **PCL_Plus 正式线**的完整源码快照，可直接作为一个独立 GitHub 仓库上传。
目录名沿用最初的 `V1.0-SRC`，内容随主仓库正式线一起前进（当前 = `1.1.1R`）。

| 项 | 值 |
| --- | --- |
| 版本 | `1.1.1R`（`Plain Craft Launcher 2/metadata.json` 为唯一版本源，`code` 2） |
| 更新线 | 正式线（`main`） |
| 上游基线 | PCL 2.12.1 / PCL-CE 1.6.4 |
| 目标框架 | .NET 10（`net10.0-windows`）+ WPF |
| 快照内容 | 全部 `PCL.Core` / `PCL.Core.SourceGenerators` / `PCL.Core.Test` / `Plain Craft Launcher 2` 源码、文档、工具、发布脚本 |

## 已包含的改造

- 前端命名空间改为**跟随目录**（`PCL.Pages.PageLaunch`、`PCL.Modules.Base` ……），类名未变，`GlobalUsings.cs` 保持原有可见性。
- **Lunar Client 支持**：`PCL.Core/App/Lunar`（IPC、安装、账号、社交）、`Modules/Lunar`、`Pages/PageLunar`、设置里的 `Lunar` 页，以及实例选择页侧边栏的「Lunar Client」入口。
- **实例选择页侧边栏新增「平台」分组**：「基岩版」「Lunar Client」两个入口，不再需要顶栏按钮。
- 更新链：源码仓 `x1B1C1/PCL_Plus` 为主服务器，`x1B1C1/PCL_Plus_OTA` 为备用服务器（主服务器全部通道失败才切换）。
- 可移植性修复：数据目录不可写时自动回退到程序目录；单例锁不可用不再阻断启动；启动期未处理异常弹框并写 `crash-*.log`。
- donor（PCL Lite）外壳修复：页切换动画两栏合并为同一组（消除撕裂）、`AniControlEnabled` 用 try/finally 保护、导航按钮按 `Tag` 查找、原生 `ScrollBar`/`ScrollViewer` 样式、多行输入弹框。

## 构建

```powershell
dotnet build "Plain Craft Launcher 2\Plain Craft Launcher 2.csproj" -c Debug
```

产物在 `Plain Craft Launcher 2\bin\Debug\net10.0-windows\`。发布单文件：

```powershell
dotnet publish "Plain Craft Launcher 2\Plain Craft Launcher 2.csproj" -c Release -p:Platform=x64 -r win-x64 --self-contained true -o ./publish-x64
```

> 注意：不要用 `Plain Craft Launcher 2.slnx` 构建（Restore 阶段会失败），直接构建 csproj。
> `Modules\Terracotta\Runtime\terracotta.exe` 是编译期嵌入资源，删掉会导致编译失败。

## 未包含

`bin/`、`obj/`、`publish-*/`、`.git/`、演示视频（`*.mp4`）、`release/` 下的 exe 与 sha256。其余文件与主仓库一致。

## 分支与更新

- 本版属于 **正式线**：版本后缀不是 `beta`，客户端因此读**主服务器**
  `x1B1C1/PCL_Plus` 的 `main` 分支里的 `update.json` / `updatev2.json`；
  主服务器不可用时切到备用服务器 `x1B1C1/PCL_Plus_OTA`。测试版（后缀 `beta`）读两个仓库的 `beta` 分支。
- 安装包清单为 `requireAdministrator`：双击即请求管理员权限（UAC 选「是」），任意目录都可运行；
  开发者署名 `xL1nUwU`（`csproj` 的 `Company`/`Authors`/`Copyright` + 关于页「开发者」一行）。
  目录不可写时数据目录会依次回退到 `<exeDir>\PCL`、`%LOCALAPPDATA%`。
