using PCL.Core.App.Configuration;

namespace PCL.Core.App;

/// <summary>
/// 全局配置类。
/// </summary>
// ReSharper disable InconsistentNaming
public static partial class Config
{
    /// <summary>
    /// 系统配置。
    /// </summary>
    [ConfigGroup("System")] partial class SystemConfigGroup
    {
        // /// <summary>
        // /// 系统缓存目录。
        // /// </summary>
        // [ConfigItem<string>("SystemSystemCache", "")] public partial string CacheDirectory { get; set; }

        /// <summary>
        /// 禁用硬件加速。
        /// </summary>
        [ConfigItem<bool>("SystemDisableHardwareAcceleration", false)] public partial bool DisableHardwareAcceleration { get; set; }

        /// <summary>
        /// 隐私模式：不弹窗询问，直接拒绝所有未永久授权的网络用途。
        /// </summary>
        [ConfigItem<bool>("SystemPrivacyMode", false)] public partial bool PrivacyMode { get; set; }

        /// <summary>
        /// 实时日志最大行数。
        /// </summary>
        [ConfigItem<int>("SystemMaxLog", 13)] public partial int MaxGameLog { get; set; }

        /// <summary>
        /// 动画帧率上限。
        /// </summary>
        [ConfigItem<int>("UiAniFPS", 59)] public partial int AnimationFpsLimit { get; set; }

        [ConfigItem<string>("Profile", "{\"lastUsed\":-1,\"profiles\":[]}", ConfigSource.SharedEncrypt)] public partial string Profiles { get; set; }

    }

    /// <summary>
    /// 网络配置。
    /// </summary>
    [ConfigGroup("Network")] partial class NetworkConfigGroup
    {
        [ConfigItem<bool>("SystemNetEnableDoH", true)] public partial bool EnableDoH { get; set; }

        /// <summary>
        /// 永久授权的网络用途 Id，以 | 分隔。
        /// </summary>
        [ConfigItem<string>("NetworkAllowedPurposes", "")] public partial string AllowedPurposes { get; set; }

        /// <summary>
        /// 是否已写入过首次启动的默认网络白名单。写入一次后不再重复，用户撤销的条目不会被重新加回。
        /// </summary>
        [ConfigItem<bool>("NetworkConsentSeeded", false)] public partial bool ConsentSeeded { get; set; }

        /// <summary>
        /// 授权全部连接。
        /// <para>
        /// 默认开启：所有网络用途与未登记域名一律放行，不再弹出授权窗口。
        /// 关掉之后才回到「按用途逐个确认」的细粒度模式。
        /// </para>
        /// </summary>
        [ConfigItem<bool>("NetworkConsentAllowAll", true)] public partial bool ConsentAllowAll { get; set; }

        [ConfigGroup("HttpProxy")] partial class HttpProxyConfigGroup
        {
            [ConfigItem<string>("SystemHttpProxy", "", ConfigSource.SharedEncrypt)] public partial string CustomAddress { get; set; }
            [ConfigItem<int>("SystemHttpProxyType", 1)] public partial int Type { get; set; }
            [ConfigItem<string>("SystemHttpProxyCustomUsername", "")] public partial string CustomUsername { get; set; }
            [ConfigItem<string>("SystemHttpProxyCustomPassword", "")] public partial string CustomPassword { get; set; }
        }
    }

    /// <summary>
    /// 调试配置
    /// </summary>
    [ConfigGroup("Debug")] partial class DebugConfigGroup
    {
        [ConfigItem<bool>("SystemDebugMode", false)] public partial bool Enabled { get; set; }
        [ConfigItem<int>("SystemDebugAnim", 9)] public partial int AnimationSpeed { get; set; }
        [ConfigItem<bool>("SystemDebugDelay", false)] public partial bool AddRandomDelay { get; set; }
        [ConfigItem<bool>("SystemDebugSkipCopy", false)] public partial bool DontCopy { get; set; }
        [ConfigItem<bool>("SystemDebugAllowRestrictedFeature", false)] public partial bool AllowRestrictedFeature { get; set; }
    }

    /// <summary>
    /// 下载配置。
    /// </summary>
    [ConfigGroup("Download")] partial class DownloadConfigGroup
    {
        // 保留原配置键，升级后仍沿用用户已设置的数值（值 + 1 为连接上限）。
        [ConfigItem<int>("ToolDownloadThread", 63)] public partial int ThreadLimit { get; set; }
        [ConfigItem<int>("ToolDownloadFileConnection", 7)] public partial int FileConnectionLimit { get; set; }
        [ConfigItem<int>("ToolDownloadSpeed", 42)] public partial int SpeedLimit { get; set; }
        [ConfigItem<DownloadHttpMode>("ToolDownloadHttpMode", DownloadHttpMode.Auto)] public partial DownloadHttpMode HttpMode { get; set; }
        [ConfigItem<int>("ToolDownloadSource", 1)] public partial int FileSource { get; set; }
        [ConfigItem<int>("ToolDownloadVersion", 1)] public partial int VersionListSource { get; set; }
        [ConfigItem<bool>("ToolDownloadAutoSelectVersion", true)] public partial bool AutoSelectInstance { get; set; }
        [ConfigItem<bool>("ToolFixAuthlib", true)] public partial bool FixAuthLib { get; set; }

        /// <summary>
        /// 第三方资源配置。
        /// </summary>
        [ConfigGroup("Comp")] partial class CompConfigGroup
        {
            [ConfigItem<int>("ToolDownloadTranslate", 0)] public partial int NameFormatV1 { get; set; }
            [ConfigItem<int>("ToolDownloadTranslateV2", 1)] public partial int NameFormatV2 { get; set; }
            [ConfigItem<bool>("ToolDownloadIgnoreQuilt", true)] public partial bool IgnoreQuilt { get; set; }
            [ConfigItem<bool>("ToolDownloadAutoInstallDependencies", true)] public partial bool AutoInstallDependencies { get; set; }
            [ConfigItem<bool>("ToolDownloadClipboard", false)] public partial bool ReadClipboard { get; set; }
            [ConfigItem<int>("ToolDownloadMod", 1)] public partial int CompSourceSolution { get; set; }
            [ConfigItem<int>("ToolModLocalNameStyle", 0)] public partial int UiCompNameSolution { get; set; }
            [ConfigItem<int>("ToolDownloadQuickBehavior", 0)] public partial int QuickDownloadBehavior { get; set; }
        }
    }

    /// <summary>
    /// 工具配置。
    /// </summary>
    [ConfigGroup("Tool")] partial class ToolConfigGroup
    {
        [ConfigItem<bool>("ToolHelpChinese", true)] public partial bool AutoChangeLanguage { get; set; }
        // [ConfigItem<int>("ToolUpdateAlpha", 0, ConfigSource.SharedEncrypt)] public partial int Alpha { get; set; }
        [ConfigItem<bool>("ToolUpdateRelease", false)] public partial bool ReleaseNotification { get; set; }
        [ConfigItem<bool>("ToolUpdateSnapshot", false)] public partial bool SnapshotNotification { get; set; }
    }

    /// <summary>
    /// 更新配置。
    /// </summary>
    [ConfigGroup("Update")] partial class UpdateConfigGroup
    {
        /// <summary>
        /// 自动更新总开关。默认关闭：装完不会自己联网查版本，只有用户手动点检查才会去查。
        /// </summary>
        [ConfigItem<bool>("SystemAutoUpdate", false, ConfigSource.Local)] public partial bool AutoUpdate { get; set; }

        /// <summary>
        /// 自动更新行为。只在 <see cref="AutoUpdate"/> 打开时生效。
        /// </summary>
        [ConfigItem<LauncherAutoUpdateBehavior>("SystemSystemUpdate", LauncherAutoUpdateBehavior.DownloadAndAnnounce, ConfigSource.Local)] public partial LauncherAutoUpdateBehavior UpdateMode { get; set; }

        /// <summary>
        /// 更新分支。
        /// </summary>
        [ConfigItem<UpdateChannel>("SystemUpdateChannel", UpdateChannel.Stable, ConfigSource.Local)] public partial UpdateChannel UpdateChannel { get; set; }

        /// <summary>
        /// 已展示过更新说明的版本号；与当前版本一致时不再弹出。
        /// </summary>
        [ConfigItem<string>("SystemUpdateNotesShown", "", ConfigSource.Local)] public partial string LastNotesVersion { get; set; }

        /// <summary>
        /// 用户在更新说明里勾选「下次更新前不再弹出」时记录的版本号。
        /// </summary>
        [ConfigItem<string>("SystemUpdateNotesDismissed", "", ConfigSource.Local)] public partial string DismissedNotesVersion { get; set; }
    }

    /// <summary>
    /// 联机大厅配置。
    /// </summary>
    [ConfigGroup("Link")] partial class LinkConfigGroup
    {
        /// <summary>
        /// 大厅用户名。
        /// </summary>
        [ConfigItem<string>("LinkUsername", "")] public partial string Username { get; set; }

        /// <summary>
        /// 中继方式。
        /// </summary>
        [ConfigItem<LinkRelayBehavior>("LinkRelayType", LinkRelayBehavior.Default)] public partial LinkRelayBehavior RelayType { get; set; }

        /// <summary>
        /// 中继服务器类型 (社区/自有)。
        /// </summary>
        [ConfigItem<int>("LinkServerType", 1)] public partial int ServerType { get; set; }

        /// <summary>
        /// 延迟优先模式。
        /// </summary>
        [ConfigItem<bool>("LinkLatencyFirstMode", true)] public partial bool UseLatencyFirstMode { get; set; }

        /// <summary>
        /// 自定义中继服务器。
        /// </summary>
        [ConfigItem<string>("LinkRelayServer", "")] public partial string CustomRelayServer { get; set; }

        /// <summary>
        /// 传输协议优先策略。
        /// </summary>
        [ConfigItem<LinkProtocolPreference>("LinkProtocolPreference", LinkProtocolPreference.Tcp)] public partial LinkProtocolPreference ProtocolPreference { get; set; }

        /// <summary>
        /// 尝试使用端口猜测打通对称性 NAT。
        /// </summary>
        [ConfigItem<bool>("LinkTryPunchSym", true)] public partial bool TryPunchSym { get; set; }

        /// <summary>
        /// 启用 IPv6。
        /// </summary>
        [ConfigItem<bool>("LinkEnableIPv6", true)] public partial bool EnableIPv6 { get; set; }
        
        /// <summary>
        /// 在日志中输出 Cli 信息以用于调试。
        /// </summary>
        [ConfigItem<bool>("LinkEnableCliOutput", false)] public partial bool EnableCliOutput { get; set; }
    }

    /// <summary>
    /// 个性化配置。
    /// </summary>
    [ConfigGroup("Preference")] partial class PreferenceConfigGroup
    {
        /// <summary>
        /// 启动时显示 Logo。
        /// </summary>
        [ConfigItem<bool>("UiLauncherLogo", true, ConfigSource.Local)] public partial bool ShowStartupLogo { get; set; }

        /// <summary>
        /// 锁定窗口大小。
        /// </summary>
        [ConfigItem<bool>("UiLockWindowSize", false)] public partial bool LockWindowSize { get; set; }

        /// <summary>
        /// 在启动游戏时显示你知道吗。
        /// </summary>
        [ConfigItem<bool>("UiShowLaunchingHint", true, ConfigSource.Local)] public partial bool ShowLaunchingHint { get; set; }

        /// <summary>
        /// 标题内容类型。
        /// </summary>
        [ConfigItem<LauncherTitleType>("UiLogoType", LauncherTitleType.Default, ConfigSource.Local)] public partial LauncherTitleType WindowTitleType { get; set; }

        /// <summary>
        /// 窗口标题文本。
        /// </summary>
        [ConfigItem<string>("UiLogoText", "", ConfigSource.Local)] public partial string WindowTitleCustomText { get; set; }

        /// <summary>
        /// 导航栏居左。
        /// </summary>
        [ConfigItem<bool>("UiLogoLeft", false, ConfigSource.Local)] public partial bool TopBarLeftAlign { get; set; }

        /// <summary>
        /// 全局字体。
        /// </summary>
        [ConfigItem<string>("UiFont", "", ConfigSource.Local)] public partial string Font { get; set; }

        /// <summary>
        /// MOTD 字体。
        /// </summary>
        [ConfigItem<string>("UiMotdFont", "", ConfigSource.Local)] public partial string MotdFont { get; set; }

        /// <summary>
        /// 详细实例分类。
        /// </summary>
        [ConfigItem<bool>("DetailedInstanceClassification", false, ConfigSource.Local)] public partial bool DetailedInstanceClassification {  get; set; }

        /// <summary>
        /// 本地化配置。
        /// </summary>
        [ConfigGroup("Localization", ConfigSource.Local)] partial class LocalizationConfigGroup
        {
            /// <summary>
            /// UI 语言。auto 表示跟随系统语言。
            /// </summary>
            [ConfigItem<string>("UiLanguage", "auto")] public partial string Language { get; set; }

            /// <summary>
            /// UI 展示格式所使用的区域性。auto 表示跟随系统区域格式。
            /// </summary>
            [ConfigItem<string>("UiFormatCulture", "auto")] public partial string FormatCulture { get; set; }

            /// <summary>
            /// 区域覆盖。auto 表示自动判断。
            /// </summary>
            [ConfigItem<string>("UiRegion", "auto")] public partial string Region { get; set; }
        }

        /// <summary>
        /// 界面主题配置。
        /// </summary>
        [ConfigGroup("Theme")] partial class ThemeConfigGroup
        {
            /// <summary>
            /// 配色主题模式。
            /// </summary>
            [ConfigItem<ColorMode>("UiDarkMode", ColorMode.Light)] public partial ColorMode ColorMode { get; set; }

            /// <summary>
            /// 暗色配色主题。
            /// </summary>
            [ConfigItem<ColorTheme>("UiDarkColor", ColorTheme.CatBlue)] public partial ColorTheme DarkColor { get; set; }

            /// <summary>
            /// 亮色配色主题。
            /// </summary>
            [ConfigItem<ColorTheme>("UiLightColor", ColorTheme.CatBlue)] public partial ColorTheme LightColor { get; set; }

            /// <summary>
            /// 窗口透明度。
            /// </summary>
            [ConfigItem<int>("UiLauncherTransparent", 600, ConfigSource.Local)] public partial int WindowOpacity { get; set; }

            // ---- 自定义主题 API ----
            // 移植自原版 PCL2 的配色引擎（PclThemeEngine），启用后忽略上面的四个预设配色，
            // 直接按色相 / 饱和度 / 明度调整 / 标题栏色相偏移生成整套八级色阶。
            // 色相 0-360 覆盖整个色环，等于把可选主题从 4 个扩展到无穷个。

            /// <summary>
            /// 是否启用自定义主题色。
            /// <para>选中任意主题（含预设）后即为 <see langword="true"/>，此时配色由原版 HSL 引擎生成。</para>
            /// </summary>
            [ConfigItem<bool>("UiCustomTheme", true, ConfigSource.Local)] public partial bool CustomThemeEnabled { get; set; }

            /// <summary>
            /// 自定义主题：色相 (H)，0-360。
            /// </summary>
            [ConfigItem<int>("UiLauncherHue", 213, ConfigSource.Local)] public partial int WindowHue { get; set; }

            /// <summary>
            /// 自定义主题：饱和度 (S)，0-100。
            /// </summary>
            [ConfigItem<int>("UiLauncherSat", 85, ConfigSource.Local)] public partial int WindowSat { get; set; }

            /// <summary>
            /// 自定义主题：明度调整 (L)，存储值 20 表示不调整，对应实际偏移 <c>存储值 - 20</c>。
            /// </summary>
            [ConfigItem<int>("UiLauncherLight", 20, ConfigSource.Local)] public partial int WindowLight { get; set; }

            /// <summary>
            /// 自定义主题：标题栏色相偏移，存储值 90 表示纯色渐变，对应实际偏移 <c>存储值 - 90</c>。
            /// </summary>
            [ConfigItem<int>("UiLauncherDelta", 90, ConfigSource.Local)] public partial int WindowDelta { get; set; }

            /// <summary>
            /// 自定义主题：标题栏三个色标各自的色相偏移，逗号分隔。
            /// <para>
            /// 原版有两个预设用的是非对称渐变（青绿 <c>5,-5,5</c>、星空蓝 <c>-30,10,50</c>），
            /// 单个 <see cref="WindowDelta"/> 表达不了，因此单独存一份。留空表示使用对称渐变。
            /// </para>
            /// </summary>
            [ConfigItem<string>("UiLauncherDeltaTriple", "", ConfigSource.Local)] public partial string WindowDeltaTriple { get; set; }

            /// <summary>
            /// 当前选中的主题编号，对应原版 <c>UiLauncherTheme</c>。
            /// <para>
            /// 取值与 <c>PclThemePresets</c> 一致，<c>14</c> 表示「自定义」（由滑块与色卡决定参数）。
            /// </para>
            /// </summary>
            [ConfigItem<int>("UiLauncherTheme", 0, ConfigSource.Local)] public partial int ThemeSelected { get; set; }

            /// <summary>
            /// 是否给按钮等控件启用液态玻璃材质。
            /// <para>
            /// 默认关闭。只作用于控件自身（边缘折射、色散、内侧高光），
            /// <b>不会改动界面背景</b>。
            /// </para>
            /// </summary>
            [ConfigItem<bool>("UiLiquidGlass", false, ConfigSource.Local)] public partial bool LiquidGlassEnabled { get; set; }

            /// <summary>
            /// 液态玻璃：边缘聚光（折射感）强度，0-100。
            /// </summary>
            [ConfigItem<int>("UiLiquidGlassRefraction", 70, ConfigSource.Local)] public partial int LiquidGlassRefraction { get; set; }

            /// <summary>
            /// 液态玻璃：顶部高光亮度，0-100。
            /// </summary>
            [ConfigItem<int>("UiLiquidGlassHighlight", 72, ConfigSource.Local)] public partial int LiquidGlassHighlight { get; set; }

            /// <summary>
            /// 液态玻璃：色散强度，0-100。
            /// </summary>
            [ConfigItem<int>("UiLiquidGlassDispersion", 35, ConfigSource.Local)] public partial int LiquidGlassDispersion { get; set; }

            /// <summary>
            /// 是否启用亚克力窗口（标题栏与窗口内部透出桌面模糊）。
            /// <para>默认关闭。开启后会隐藏自定义背景图/视频，由 Windows DWM 提供真实桌面亚克力。</para>
            /// </summary>
            [ConfigItem<bool>("UiAcrylic", false, ConfigSource.Local)] public partial bool AcrylicEnabled { get; set; }
        }

        /// <summary>
        /// 背景内容。
        /// </summary>
        [ConfigGroup("Background")] partial class BackgroundConfigGroup
        {
            /// <summary>
            /// 彩色底部填充。
            /// </summary>
            [ConfigItem<bool>("UiBackgroundColorful", true, ConfigSource.Local)] public partial bool BackgroundColorful { get; set; }

            /// <summary>
            /// 透明度。
            /// </summary>
            [ConfigItem<int>("UiBackgroundOpacity", 1000, ConfigSource.Local)] public partial int WallpaperOpacity { get; set; }

            /// <summary>
            /// 旋转。
            /// </summary>
            [ConfigItem<int>("UiBackgroundCarousel", 1000, ConfigSource.Local)] public partial int WallpaperCarousel { get; set; }

            /// <summary>
            /// 模糊遮罩。
            /// </summary>
            [ConfigItem<int>("UiBackgroundBlur", 0, ConfigSource.Local)] public partial int WallpaperBlurRadius { get; set; }

            /// <summary>
            /// 内容裁剪模式。
            /// </summary>
            [ConfigItem<int>("UiBackgroundSuit", 0, ConfigSource.Local)] public partial int WallpaperSuitMode { get; set; }

            /// <summary>
            /// 视频自动暂停。
            /// </summary>
            [ConfigItem<bool>("UiAutoPauseVideo", true, ConfigSource.Local)] public partial bool AutoPauseVideo { get; set; }

            /// <summary>
            ///     没有自定义背景内容时，使用内置的默认背景图（随主题切换昼夜两套）。
            ///     <para>
            ///         内置图来自 PCL-Living-Fork 并随启动器打包；<c>PCL\Pictures\</c> 里放了图片或视频时以自定义内容优先。
            ///     </para>
            /// </summary>
            [ConfigItem<bool>("UiDefaultWallpaper", true, ConfigSource.Local)] public partial bool DefaultWallpaper { get; set; }
        }

        /// <summary>
        /// 高级材质。
        /// </summary>
        [ConfigGroup("Blur")] partial class BlurConfigGroup
        {
            /// <summary>
            /// 是否启用。
            /// </summary>
            [ConfigItem<bool>("UiBlur", false, ConfigSource.Local)] public partial bool IsEnabled { get; set; }

            /// <summary>
            /// 模糊半径。
            /// </summary>
            [ConfigItem<int>("UiBlurValue", 16, ConfigSource.Local)] public partial int Radius { get; set; }

            /// <summary>
            /// 采样率。
            /// </summary>
            [ConfigItem<int>("UiBlurSamplingRate", 70, ConfigSource.Local)] public partial int SamplingRate { get; set; }

            /// <summary>
            /// 模糊方法。
            /// </summary>
            [ConfigItem<int>("UiBlurType", 0, ConfigSource.Local)] public partial int KernelType { get; set; }
        }

        /// <summary>
        /// 自定义主页。
        /// </summary>
        [ConfigGroup("Homepage")] partial class HomepageConfigGroup
        {
            /// <summary>
            /// 主页来源类型。0 = 空白，1 = 本地文件，2 = 联网，3 = 预设。
            /// <para>
            /// 默认用 3（预设）而不是 0：预设里第一个就是 PCL_Plus 欢迎页，
            /// 首次启动直接看到欢迎页；用户主动选「空白」才会真的什么都不显示。
            /// </para>
            /// </summary>
            [ConfigItem<int>("UiCustomType", 3, ConfigSource.Local)] public partial int Type { get; set; }

            /// <summary>
            /// 预设选项。
            /// </summary>
            [ConfigItem<int>("UiCustomPreset", 0, ConfigSource.Local)] public partial int SelectedPreset { get; set; }

            /// <summary>
            /// 自定义 URL。
            /// </summary>
            [ConfigItem<string>("UiCustomNet", "", ConfigSource.Local)] public partial string CustomUrl { get; set; }
        }

        /// <summary>
        /// 背景音乐。
        /// </summary>
        [ConfigGroup("Music")] partial class MusicConfigGroup
        {
            /// <summary>
            /// 音量。
            /// </summary>
            [ConfigItem<int>("UiMusicVolume", 500, ConfigSource.Local)] public partial int Volume { get; set; }

            /// <summary>
            /// 启动游戏后自动暂停。
            /// </summary>
            [ConfigItem<bool>("UiMusicStop", false, ConfigSource.Local)] public partial bool StopInGame { get; set; }

            /// <summary>
            /// 启动游戏后自动开始播放。
            /// </summary>
            [ConfigItem<bool>("UiMusicStart", false, ConfigSource.Local)] public partial bool StartInGame { get; set; }

            /// <summary>
            /// 自动开始播放。
            /// </summary>
            [ConfigItem<bool>("UiMusicAuto", true, ConfigSource.Local)] public partial bool StartOnStartup { get; set; }

            /// <summary>
            /// 随机播放。
            /// </summary>
            [ConfigItem<bool>("UiMusicRandom", true, ConfigSource.Local)] public partial bool ShufflePlayback { get; set; }

            /// <summary>
            /// 启用 SMTC。
            /// </summary>
            [ConfigItem<bool>("UiMusicSMTC", true, ConfigSource.Local)] public partial bool EnableSMTC { get; set; }
        }

        /// <summary>
        /// 功能隐藏。
        /// </summary>
        [ConfigGroup("Hide")]
        partial class HideConfigGroup
        {
            // 主页面
            [ConfigItem<bool>("UiHiddenPageDownload", false, ConfigSource.Local)] public partial bool PageDownload { get; set; }
            [ConfigItem<bool>("UiHiddenPageBedrock", false, ConfigSource.Local)] public partial bool PageBedrock { get; set; }
            [ConfigItem<bool>("UiHiddenPageSetup", false, ConfigSource.Local)] public partial bool PageSetup { get; set; }
            [ConfigItem<bool>("UiHiddenPageTools", false, ConfigSource.Local)] public partial bool PageTools { get; set; }

            // 子页面 设置
            [ConfigItem<bool>("UiHiddenSetupLaunch", false, ConfigSource.Local)] public partial bool SetupLaunch { get; set; }
            [ConfigItem<bool>("UiHiddenSetupUi", false, ConfigSource.Local)] public partial bool SetupUi { get; set; }
            [ConfigItem<bool>("UiHiddenSetupLauncherLanguage", false, ConfigSource.Local)] public partial bool SetupLauncherLanguage { get; set; }
            [ConfigItem<bool>("UiHiddenSetupLauncherMisc", false, ConfigSource.Local)] public partial bool SetupLauncherMisc { get; set; }
            [ConfigItem<bool>("UiHiddenSetupGameManage", false, ConfigSource.Local)] public partial bool SetupGameManage { get; set; }
            [ConfigItem<bool>("UiHiddenSetupJava", false, ConfigSource.Local)] public partial bool SetupJava { get; set; }
            [ConfigItem<bool>("UiHiddenSetupUpdate", false, ConfigSource.Local)] public partial bool SetupUpdate { get; set; }
            [ConfigItem<bool>("UiHiddenSetupAbout", false, ConfigSource.Local)] public partial bool SetupAbout { get; set; } // 修正名称
            [ConfigItem<bool>("UiHiddenSetupFeedback", false, ConfigSource.Local)] public partial bool SetupFeedback { get; set; } // 修正名称
            [ConfigItem<bool>("UiHiddenSetupLog", false, ConfigSource.Local)] public partial bool SetupLog { get; set; } // 修正名称

            // 子页面 工具
            [ConfigItem<bool>("UiHiddenToolsTest", false, ConfigSource.Local)] public partial bool ToolsTest { get; set; } // 新增

            // 子页面 实例设置
            [ConfigItem<bool>("UiHiddenVersionEdit", false, ConfigSource.Local)] public partial bool InstanceEdit { get; set; }
            [ConfigItem<bool>("UiHiddenVersionExport", false, ConfigSource.Local)] public partial bool InstanceExport { get; set; }
            [ConfigItem<bool>("UiHiddenVersionSave", false, ConfigSource.Local)] public partial bool InstanceSave { get; set; }
            [ConfigItem<bool>("UiHiddenVersionScreenshot", false, ConfigSource.Local)] public partial bool InstanceScreenshot { get; set; }
            [ConfigItem<bool>("UiHiddenVersionMod", false, ConfigSource.Local)] public partial bool InstanceMod { get; set; }
            [ConfigItem<bool>("UiHiddenVersionResourcePack", false, ConfigSource.Local)] public partial bool InstanceResourcePack { get; set; }
            [ConfigItem<bool>("UiHiddenVersionShader", false, ConfigSource.Local)] public partial bool InstanceShader { get; set; }
            [ConfigItem<bool>("UiHiddenVersionSchematic", false, ConfigSource.Local)] public partial bool InstanceSchematic { get; set; }
            [ConfigItem<bool>("UiHiddenVersionServer", false, ConfigSource.Local)] public partial bool InstanceServer { get; set; }

            // 特定功能
            [ConfigItem<bool>("UiHiddenFunctionSelect", false, ConfigSource.Local)] public partial bool FunctionSelect { get; set; }
            [ConfigItem<bool>("UiHiddenFunctionModUpdate", false, ConfigSource.Local)] public partial bool FunctionModUpdate { get; set; }
            [ConfigItem<bool>("UiHiddenFunctionHidden", false, ConfigSource.Local)] public partial bool FunctionHidden { get; set; }
        }

            [ConfigGroup("Lunar")] partial class LunarConfigGroup
            {
                /// <summary>
                /// 启动前校验物料文件的 SHA-1。
                /// <para>
                /// 关掉之后只判断文件在不在，不算哈希。物料有几十 MB 的 jar，
                /// 机械盘或慢速盘上校验要好几秒，嫌慢可以关。
                /// </para>
                /// </summary>
                [ConfigItem<bool>("LunarVerifyFiles", true, ConfigSource.Local)] public partial bool VerifyFiles { get; set; }

                /// <summary>
                /// 上次选择的 Lunar 子版本，例如 <c>1.8.9</c>、<c>1.21.4</c>。
                /// <para>
                /// 空值表示「还没选过」，按 <c>ModLunar.DefaultSubVersion</c> 处理。
                /// 记在这里而不是界面里，是为了下次打开还停在上次玩的版本。
                /// </para>
                /// </summary>
                [ConfigItem<string>("LunarSubVersion", "", ConfigSource.Local)] public partial string SubVersion { get; set; }

                /// <summary>
                /// 选中的 loader（服务端叫 module），例如 <c>lunar</c>（Lunar + OptiFine）、
                /// <c>lunar-noOF</c>（原版）、<c>fabric</c>、<c>forge</c>。
                /// <para>
                /// 这里只存「用户点过哪个」，不保证对当前版本有效：换到不提供这个 loader 的版本时，
                /// <c>ModLunar.SelectedModule</c> 会退回该版本的官方默认值，但**不会覆盖这里的值** ——
                /// 切回原来那个版本时用户的选择还在。
                /// </para>
                /// </summary>
                [ConfigItem<string>("LunarModule", "", ConfigSource.Local)] public partial string ModuleId { get; set; }

                /// <summary>
                /// 选中的 Lunar 账号（<c>accounts.json</c> 里的 localId）。
                /// <para>
                /// Lunar 游戏进程只认它自己账户库里的激活账号，不认命令行 accessToken，
                /// 所以这里存的是「要切成哪个账号」，启动前会同步进 Lunar 的
                /// <c>activeAccountLocalId</c>。空值表示跟随 Lunar 当前激活的账号。
                /// </para>
                /// </summary>
                [ConfigItem<string>("LunarAccount", "", ConfigSource.Local)] public partial string AccountLocalId { get; set; }

                /// <summary>
                /// Lunar 的堆上限（MB）。<c>0</c> 表示跟随 PCL 全局内存设置。
                /// <para>
                /// 单独开一项而不是直接复用 <see cref="LaunchConfigGroup" /> 的滑块，是因为
                /// Lunar 的 JRE 由它自己按版本下发（17 / 21 / 25），内存需求跟原版实例不一样，
                /// 强行套用全局值容易给出一个对某个版本偏小的数字。
                /// </para>
                /// </summary>
                [ConfigItem<int>("LunarMemoryMb", 0, ConfigSource.Local)] public partial int MemoryMb { get; set; }

                /// <summary>
                /// 全局附加 JVM 参数，只对 Lunar 生效。
                /// <para>
                /// 会被拼在 Lunar 按版本下发的 JVM 参数<b>之后</b>：JVM 对重复参数取最后一次，
                /// 这样用户写的 <c>-Xmx</c>、<c>-XX:+UseZGC</c> 才能盖掉官方值。
                /// </para>
                /// </summary>
                [ConfigItem<string>("LunarJvmArgs", "", ConfigSource.Local)] public partial string JvmArgs { get; set; }

                /// <summary>
                /// 覆盖 Lunar 自带的 JRE，指向一个具体的 <c>java.exe</c>。空值表示用 Lunar 的。
                /// <para>
                /// 只在文件确实存在时才生效，写错了会退回自动定位，不会把启动搞崩。
                /// </para>
                /// </summary>
                [ConfigItem<string>("LunarJavaPath", "", ConfigSource.Local)] public partial string JavaPath { get; set; }

                /// <summary>
                /// 按版本覆盖的内存与 JVM 参数，JSON：<c>{"1.8.9":{"on":true,"mem":4096,"jvm":"..."}}</c>。
                /// <para>
                /// 走 <see cref="PCL.Core.App.Lunar.LunarLaunchProfile" /> 读写，别直接解析。
                /// 存成一个字符串是沿用 <c>ProfileService.Profiles</c> 的做法：
                /// 版本数量不定，拆成配置项会让配置文件越滚越大。
                /// </para>
                /// </summary>
                [ConfigItem<string>("LunarVersionOverrides", "", ConfigSource.Local)] public partial string VersionOverrides { get; set; }

                /// <summary>
                ///     Lunar 物料根目录（相当于官方启动器的 <c>~/.lunarclient</c>）。空值表示用默认位置。
                ///     <para>
                ///         物料、JRE、账户库（<c>settings/game/accounts.json</c>）都挂在这个目录下，
                ///         换目录等于换一套完整的 Lunar 环境 —— 所以改完要重新下物料。
                ///         C 盘紧张时把它挪到别的盘就是靠这一项。
                ///     </para>
                /// </summary>
                [ConfigItem<string>("LunarRoot", "", ConfigSource.Local)] public partial string Root { get; set; }

                /// <summary>
                ///     Lunar 的启动目录（存档、资源包、截图所在）。空值表示用当前 MC 根目录。
                ///     <para>
                ///         默认跟 <c>ModFolder.mcFolderSelected</c> 走，也就是玩家平时玩的那个
                ///         <c>.minecraft</c>。想单独隔离一套 Lunar 存档时可以在这里指定。
                ///     </para>
                /// </summary>
                [ConfigItem<string>("LunarGameDir", "", ConfigSource.Local)] public partial string GameDir { get; set; }
            }
    }

    /// <summary>
    /// 内置 MCP 服务（给 AI 客户端调用，用来启动游戏、整理 mod、分析实例）。
    /// <para>
    /// 默认整体关闭：它会开放「在本机读写游戏文件、启动游戏」的能力，
    /// 必须由用户主动打开，且建议同时设一个访问口令。
    /// </para>
    /// </summary>
    [ConfigGroup("Mcp")] partial class McpConfigGroup
    {
        /// <summary>
        /// 是否启用内置 MCP 服务。默认关闭。
        /// </summary>
        [ConfigItem<bool>("McpEnabled", false, ConfigSource.Local)] public partial bool Enabled { get; set; }

        /// <summary>
        /// 监听端口。固定绑定 127.0.0.1。
        /// </summary>
        [ConfigItem<int>("McpPort", 38765, ConfigSource.Local)] public partial int Port { get; set; }

        /// <summary>
        /// 访问口令。留空表示不校验（仅本机可连）。
        /// 存放在加密的共享配置里，不会以明文写进 config.v1.yml。
        /// </summary>
        [ConfigItem<string>("McpToken", "", ConfigSource.SharedEncrypt)] public partial string Token { get; set; }

        /// <summary>
        /// 允许 MCP 在游戏目录内移动、重命名、删除文件。
        /// <para>
        /// 默认关闭：打开 MCP 总开关不等于把删除权限一起交出去。
        /// 用户需要显式勾选，中间没有「一次性全授权」的捷径。
        /// </para>
        /// </summary>
        [ConfigItem<bool>("McpAllowWrite", false, ConfigSource.Local)] public partial bool AllowWrite { get; set; }

        /// <summary>
        /// 允许 MCP 启动或停止 Minecraft。默认关闭，理由同 <see cref="AllowWrite" />。
        /// </summary>
        [ConfigItem<bool>("McpAllowGameControl", false, ConfigSource.Local)] public partial bool AllowGameControl { get; set; }

        /// <summary>
        /// 允许 MCP 修改启动器自身的设置。
        /// </summary>
        [ConfigItem<bool>("McpAllowLauncherConfig", false, ConfigSource.Local)] public partial bool AllowLauncherConfig { get; set; }
    }

    /// <summary>
    /// Discord Rich Presence 配置。
    /// </summary>
    [ConfigGroup("Discord")] partial class DiscordConfigGroup
    {
        /// <summary>
        /// 是否启用 Discord 状态显示。默认关闭——这是外联功能，得用户自己开。
        /// </summary>
        [ConfigItem<bool>("DiscordRpcEnabled", false, ConfigSource.Local)] public partial bool Enabled { get; set; }

        /// <summary>
        /// Discord 应用的 Application ID。
        /// <para>
        /// 默认值是本项目自建的 Discord 应用，用户开箱即用；填别的值可以换成自己的应用
        /// （状态卡片上显示的应用名和图标会跟着变）。清空则不连接。
        /// </para>
        /// </summary>
        [ConfigItem<string>("DiscordRpcAppId", "1563608700969689108", ConfigSource.Local)]
        public partial string AppId { get; set; }

        /// <summary>
        /// 要展示的内容项，逗号分隔。取值见 <see cref="PCL.Core.Link.Discord.DiscordRpcFields"/>。
        /// 服务器地址不在默认值里——它会暴露你在玩哪个服。
        /// </summary>
        [ConfigItem<string>("DiscordRpcFields", PCL.Core.Link.Discord.DiscordRpcFields.DefaultValue, ConfigSource.Local)]
        public partial string Fields { get; set; }
    }

    // ============================================================================
    // [新增代码开始] 陶瓦联机（Terracotta）附加模块配置
    // 所属功能：可插拔的陶瓦联机集成，默认整体关闭。
    // 说明：这里只声明可持久化的配置项，不包含任何 UI 或进程逻辑；
    //       插件实现位于 Plain Craft Launcher 2\Modules\Terracotta\。
    // ============================================================================
    /// <summary>
    /// 陶瓦联机（Terracotta）附加模块配置。
    /// </summary>
    [ConfigGroup("Terracotta")] partial class TerracottaConfigGroup
    {
        /// <summary>
        /// 是否启用陶瓦联机集成。默认关闭。
        /// <para>
        /// 关闭时不会启动任何进程、线程或 HTTP 轮询，启动器原有流程完全不受影响。
        /// </para>
        /// </summary>
        [ConfigItem<bool>("TerracottaEnabled", false, ConfigSource.Local)]
        public partial bool Enabled { get; set; }

        /// <summary>
        /// 陶瓦联机可执行文件路径。留空时自动在 PCL\Terracotta、启动器目录与 PATH 中查找。
        /// </summary>
        [ConfigItem<string>("TerracottaExePath", "", ConfigSource.Local)]
        public partial string ExecutablePath { get; set; }

        /// <summary>
        /// 联机昵称。留空时由陶瓦使用默认昵称。
        /// </summary>
        [ConfigItem<string>("TerracottaPlayerName", "", ConfigSource.Local)]
        public partial string PlayerName { get; set; }

        /// <summary>
        /// 启动启动器时自动拉起陶瓦联机组件。
        /// </summary>
        [ConfigItem<bool>("TerracottaAutoStart", false, ConfigSource.Local)]
        public partial bool AutoStart { get; set; }

        /// <summary>
        /// 联机成功后，把 127.0.0.1:端口 写入当前实例的“启动时自动进入服务器”配置。
        /// </summary>
        [ConfigItem<bool>("TerracottaAutoFillServer", false, ConfigSource.Local)]
        public partial bool AutoFillServer { get; set; }

        /// <summary>
        /// 退出启动器时顺带关闭陶瓦联机组件。
        /// <para>默认关闭：陶瓦是共享守护进程，可能还有别的启动器正在使用。</para>
        /// </summary>
        [ConfigItem<bool>("TerracottaStopOnExit", false, ConfigSource.Local)]
        public partial bool StopOnExit { get; set; }
    }
    // ============================================================================
    // [新增代码结束] 陶瓦联机附加模块配置
    // ============================================================================


    /// <summary>
    /// 启动配置。
    /// </summary>
    [ConfigGroup("Launch")] partial class LaunchConfigGroup
    {
        [ConfigItem<bool>("LaunchPersonalOptionsSync", true, ConfigSource.Local)]
        public partial bool PersonalOptionsSync { get; set; }

        /// <summary>
        ///     启动前检查模组依赖（必需前置是否齐全）。
        /// </summary>
        [ConfigItem<bool>("LaunchModDependencyCheck", true, ConfigSource.Local)] public partial bool ModDependencyCheck { get; set; }

        /// <summary>
        /// 内存分配模式。
        /// </summary>
        [ConfigItem<int>("LaunchRamType", 0, ConfigSource.Local)] public partial int MemoryAllocationMode { get; set; }

        /// <summary>
        /// 自定义内存分配大小。
        /// </summary>
        [ConfigItem<int>("LaunchRamCustom", 15, ConfigSource.Local)] public partial int CustomMemorySize { get; set; }

        /// <summary>
        /// 自定义初始堆大小（-Xms）的滑块刻度值，0 表示不主动设置。仅在手动分配模式下生效，且实际值不会超过最大堆。
        /// </summary>
        [ConfigItem<int>("LaunchRamCustomInitial", 0, ConfigSource.Local)] public partial int CustomInitialMemorySize { get; set; }

        /// <summary>
        /// 是否固定堆大小：启用后额外追加 -Xms 并使其等于 -Xmx，隐式禁用内存归还以降低延迟抖动、利于 ZGC。见 #3282。
        /// </summary>
        [ConfigItem<bool>("LaunchAdvanceLockMemory", false, ConfigSource.Local)] public partial bool LockMemory { get; set; }

        /// <summary>
        /// 优先 IP 协议栈。
        /// </summary>
        [ConfigItem<JvmPreferredIpStack>("LaunchPreferredIpStack", JvmPreferredIpStack.Default)] public partial JvmPreferredIpStack PreferredIpStack { get; set; }

        /// <summary>
        /// 附加 JVM 参数。
        /// </summary>
        [ConfigItem<string>("LaunchAdvanceJvm", "-XX:+UseG1GC -XX:-UseAdaptiveSizePolicy -XX:-OmitStackTraceInFastThrow -Djdk.lang.Process.allowAmbiguousCommands=true -Dfml.ignoreInvalidMinecraftCertificates=True -Dfml.ignorePatchDiscrepancies=True -Dlog4j2.formatMsgNoLookups=true", ConfigSource.Local)] public partial string JvmArgs { get; set; }

        /// <summary>
        /// 附加游戏参数。
        /// </summary>
        [ConfigItem<string>("LaunchAdvanceGame", "", ConfigSource.Local)] public partial string GameArgs { get; set; }

        /// <summary>
        /// 额外的基岩版 GDK 便携版目录，多个目录用换行分隔。
        /// <para>
        /// 商店版（UWP）由系统注册，能自动发现；便携版是解包出来的独立目录，
        /// 位置任意，只能由用户自己指定。
        /// </para>
        /// </summary>
        [ConfigItem<string>("BedrockGdkDirectories", "", ConfigSource.Local)] public partial string BedrockGdkDirectories { get; set; }

        /// <summary>
        /// 基岩版下载目录，留空表示用默认的 <c>%LOCALAPPDATA%\PCL_Plus\Bedrock</c>。
        /// <para>
        /// GDK 包解包后动辄 2 GB，放在系统盘容易撑爆，所以允许用户换到别的盘。
        /// 安装包（<c>packages</c>）与解包产物（<c>versions</c>）都跟着这个根目录走。
        /// </para>
        /// </summary>
        [ConfigItem<string>("BedrockDownloadDirectory", "", ConfigSource.Local)] public partial string BedrockDownloadDirectory { get; set; }

        /// <summary>
        ///     基岩版 GDK 正式版安装包的内容密钥（CIK，十六进制）。
        ///     <para>
        ///         GDK 版下发的是加密的 <c>.msixvc</c>（XVC 容器），没有这个密钥解不开。
        ///         密钥属于商店分发凭据，不随启动器分发，由用户自己填写（或在构建时用
        ///         <c>PCL_BEDROCK_RELEASE_CIK</c> 环境变量注入）。留空时 GDK 包只能下载、不能解包。
        ///     </para>
        /// </summary>
        [ConfigItem<string>("BedrockReleaseCik", "", ConfigSource.Local)] public partial string BedrockReleaseCik { get; set; }

        /// <summary>基岩版 GDK 预览版安装包的内容密钥（CIK，十六进制），说明见 <see cref="BedrockReleaseCik" />。</summary>
        [ConfigItem<string>("BedrockPreviewCik", "", ConfigSource.Local)] public partial string BedrockPreviewCik { get; set; }

        /// <summary>
        /// 预启动指令。
        /// </summary>
        [ConfigItem<string>("LaunchAdvanceRun", "", ConfigSource.Local)] public partial string PreLaunchCommand { get; set; }

        /// <summary>
        /// 是否等待预启动指令完成。
        /// </summary>
        [ConfigItem<bool>("LaunchAdvanceRunWait", true, ConfigSource.Local)] public partial bool PreLaunchCommandWait { get; set; }

        /// <summary>
        /// 禁用 Java Launch Wrapper。
        /// </summary>
        [ConfigItem<bool>("LaunchAdvanceDisableJLW", true, ConfigSource.Local)] public partial bool DisableJlw { get; set; }

        /// <summary>
        /// 禁用 LegacyFix
        /// </summary>
        [ConfigItem<bool>("LaunchAdvanceDisableLF", false, ConfigSource.Local)] public partial bool DisableLF { get; set; }

        /// <summary>
        /// 强制使用高性能显卡。
        /// </summary>
        [ConfigItem<bool>("LaunchAdvanceGraphicCard", true)] public partial bool SetGpuPreference { get; set; }

        /// <summary>
        /// 使用 java 而不是 javaw。
        /// </summary>
        [ConfigItem<bool>("LaunchAdvanceNoJavaw", false)] public partial bool NoJavaw { get; set; }

        /// <summary>
        /// 禁用 LWJGL Unsafe Agent。
        /// </summary>
        [ConfigItem<bool>("LaunchAdvanceDisableLwjglUnsafeAgent", false)] public partial bool DisableLwjglUnsafeAgent { get; set; }

        /// <summary>
        /// 禁用自动崩溃分析。
        /// </summary>
        [ConfigItem<bool>("LaunchAdvanceDisableCrashAnalysis", false, ConfigSource.Local)] public partial bool DisableCrashAnalysis { get; set; }

        /// <summary>
        /// 渲染器。
        /// </summary>
        [ConfigItem<int>("LaunchAdvanceRenderer", 0 ,ConfigSource.Local)] public partial int Renderer { get; set; }

        /// <summary>
        /// 游戏窗口标题。
        /// </summary>
        [ConfigItem<string>("LaunchArgumentTitle", "", ConfigSource.Local)] public partial string Title { get; set; }

        /// <summary>
        /// 自定义左下角版本信息。
        /// </summary>
        [ConfigItem<string>("LaunchArgumentInfo", "PCL_Plus", ConfigSource.Local)] public partial string TypeInfo { get; set; }

        /// <summary>
        /// 选择的默认 Java 实例。
        /// </summary>
        [ConfigItem<string>("LaunchArgumentJavaSelect", "")] public partial string SelectedJava { get; set; }

        /// <summary>
        /// 版本隔离 V2。
        /// </summary>
        [ConfigItem<int>("LaunchArgumentIndieV2", 4, ConfigSource.Local)] public partial int IndieSolutionV2 { get; set; }

        /// <summary>
        /// 游戏启动后启动器可见性。
        /// </summary>
        [ConfigItem<LauncherVisibility>("LaunchArgumentVisible", LauncherVisibility.DoNothing)] public partial LauncherVisibility LauncherVisibility { get; set; }

        /// <summary>
        /// 游戏进程优先级。
        /// </summary>
        [ConfigItem<GameProcessPriority>("LaunchArgumentPriority", GameProcessPriority.Normal)] public partial GameProcessPriority ProcessPriority { get; set; }

        /// <summary>
        /// 游戏窗口宽度。
        /// </summary>
        [ConfigItem<int>("LaunchArgumentWindowWidth", 854, ConfigSource.Local)] public partial int GameWindowWidth { get; set; }

        /// <summary>
        /// 游戏窗口高度。
        /// </summary>
        [ConfigItem<int>("LaunchArgumentWindowHeight", 480, ConfigSource.Local)] public partial int GameWindowHeight { get; set; }

        /// <summary>
        /// 游戏窗口模式 (正常/最大化/全屏)。
        /// </summary>
        [ConfigItem<GameWindowSizeMode>("LaunchArgumentWindowType", GameWindowSizeMode.Default, ConfigSource.Local)] public partial GameWindowSizeMode GameWindowMode { get; set; }

        /// <summary>
        /// 正版登录方式。
        /// </summary>
        [ConfigItem<int>("LoginMsAuthType", 1)] public partial int LoginMsAuthType { get; set; }
    }

    /// <summary>
    /// 实例独立配置。<br/>
    /// 懒得写注释了，自己理解吧。
    /// </summary>
    [ConfigGroup("Instance", ConfigSource.GameInstance)] partial class InstanceConfigGroup
    {
        [ConfigItem<int>("VersionPersonalOptionsSync", 0)]
        public partial ArgConfig<int> PersonalOptionsSync { get; }

        [ConfigItem<string>("VersionAdvanceJvm", "")] public partial ArgConfig<string> JvmArgs { get; }
        [ConfigItem<string>("VersionAdvanceGame", "")] public partial ArgConfig<string> GameArgs { get; }
        [ConfigItem<int>("VersionAdvanceRenderer", 0)] public partial ArgConfig<int> Renderer { get; }
        [ConfigItem<int>("VersionAdvanceAssets", 0)] public partial ArgConfig<int> AssetVerifySolutionV1 { get; }
        [ConfigItem<bool>("VersionAdvanceAssetsV2", false)] public partial ArgConfig<bool> DisableAssetVerifyV2 { get; }
        [ConfigItem<bool>("VersionAdvanceJava", false)] public partial ArgConfig<bool> IgnoreJavaCompatibility { get; }
        [ConfigItem<bool>("VersionAdvanceDisableJlw", false)] public partial ArgConfig<bool> DisableJlwObsolete { get; }
        [ConfigItem<string>("VersionAdvanceRun", "")] public partial ArgConfig<string> PreLaunchCommand { get; }
        [ConfigItem<string>("VersionAdvanceClasspathHead", "")] public partial ArgConfig<string> ClasspathHead { get; }
        [ConfigItem<bool>("VersionAdvanceRunWait", true)] public partial ArgConfig<bool> PreLaunchCommandWait { get; }
        [ConfigItem<bool>("VersionAdvanceDisableJLW", false)] public partial ArgConfig<bool> DisableJlw { get; }
        [ConfigItem<bool>("VersionAdvanceDisableLwjglUnsafeAgent", false)] public partial ArgConfig<bool> DisableLwjglUnsafeAgent { get; }
        [ConfigItem<bool>("VersionAdvanceUseProxyV2", false)] public partial ArgConfig<bool> UseProxy { get; }
        [ConfigItem<bool>("VersionAdvanceDisableLF", false)] public partial ArgConfig<bool> DisableLF { get; }
        [ConfigItem<bool>("VersionUseDebugLog4j2Config", false)] public partial ArgConfig<bool> UseDebugLof4j2Config { get; }
        [ConfigItem<int>("VersionRamType", 2)] public partial ArgConfig<int> MemorySolution { get; }
        [ConfigItem<int>("VersionRamCustom", 15)] public partial ArgConfig<int> CustomMemorySize { get; }
        [ConfigItem<int>("VersionRamCustomInitial", 0)] public partial ArgConfig<int> CustomInitialMemorySize { get; }
        [ConfigItem<string>("VersionArgumentTitle", "")] public partial ArgConfig<string> Title { get; }
        [ConfigItem<bool>("VersionArgumentTitleEmpty", false)] public partial ArgConfig<bool> UseGlobalTitle { get; }
        [ConfigItem<string>("VersionArgumentInfo", "")] public partial ArgConfig<string> TypeInfo { get; }
        [ConfigItem<int>("VersionArgumentIndie", -1)] public partial ArgConfig<int> IndieV1 { get; }
        [ConfigItem<bool>("VersionArgumentIndieV2", false)] public partial ArgConfig<bool> IndieV2 { get; }
        [ConfigItem<string>("VersionArgumentJavaSelect", "使用全局设置")] public partial ArgConfig<string> SelectedJava { get; }
        [ConfigItem<string>("VersionServerEnter", "")] public partial ArgConfig<string> ServerToEnter { get; }
        /// <summary>正常退出游戏或更新前自动备份该实例的存档世界。</summary>
        [ConfigItem<bool>("VersionWorldBackupAutoEnabled", false)] public partial ArgConfig<bool> WorldBackupAutoEnabled { get; }
        /// <summary>每个世界保留的自动备份份数（1 到 50，手动备份不计入）。</summary>
        [ConfigItem<int>("VersionWorldBackupRetention", 5)] public partial ArgConfig<int> WorldBackupRetention { get; }
        [ConfigItem<bool>("VersionEnvironmentHistoryAutoCleanup", false)]
        public partial ArgConfig<bool> EnvironmentHistoryAutoCleanup { get; }

        [ConfigItem<int>("VersionEnvironmentHistoryRetention", 10)]
        public partial ArgConfig<int> EnvironmentHistoryRetention { get; }
    }

    /// <summary>
    /// 实例独立配置的认证部分
    /// </summary>
    [ConfigGroup("InstanceAuth", ConfigSource.GameInstance)] partial class InstanceAuthConfigGroup
    {
        [ConfigItem<int>("VersionServerLoginRequire", 0)] public partial ArgConfig<int> LoginRequirementSolution { get; }
        [ConfigItem<string>("VersionServerAuthRegister", "")] public partial ArgConfig<string> AuthRegisterAddress { get; }
        [ConfigItem<string>("VersionServerAuthName", "")] public partial ArgConfig<string> AuthServerDisplayName { get; }
        [ConfigItem<string>("VersionServerAuthServer", "")] public partial ArgConfig<string> AuthServerAddress { get; }
        [ConfigItem<bool>("VersionServerLoginLock", false)] public partial ArgConfig<bool> AuthLocked { get; }
    }
}
